console.log('1. process 시작.');



console.info('2. process 종료.');