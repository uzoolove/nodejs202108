function print(msg){
  console.log(msg);
}
print('1. start');

print('2. finish');