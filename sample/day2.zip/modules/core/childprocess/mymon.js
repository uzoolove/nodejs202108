var childProcess = require('child_process');
var path = require('path');
var fs = require('fs');

// node mymon.js helloserver.js 8080
// => node helloserver.js 8080

