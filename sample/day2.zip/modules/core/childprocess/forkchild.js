const path = require('path');
var filename = path.basename(__filename);
console.log(filename, '실행');

