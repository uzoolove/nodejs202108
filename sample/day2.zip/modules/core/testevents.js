const EventEmitter = require('events');



function print(msg){
  console.log(msg);
}