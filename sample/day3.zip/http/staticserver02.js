var mime = {
  'html': 'text/html',
  'svg': 'image/svg+xml',
  'jpg': 'image/jpeg',
  'png': 'image/png',
  'gif': 'image/gif',
  'css': 'text/css',
  'js': 'application/javascript'
  // ......
};

